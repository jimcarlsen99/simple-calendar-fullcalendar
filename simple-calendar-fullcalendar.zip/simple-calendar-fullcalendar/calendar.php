<?php
/*
Plugin Name:  Simple Calendar Fullcalendar
Description:  Simple Calendar Fullcalendar is a WordPress plugin which allows posts to be embedded with calendar of today's month. Simple and awesome.
Version:      1.0
Author:       Jim Carlsen
Author URI:   https://github.com/jimcarlsen99/simple-calendar-fullcalendar/
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  simple-calendar-fullcalendar
Domain Path:  /languages
*/
define ( 'SIMPLE_CALENDAR_FULLCALENDAR_FILE', __FILE__ );

// necessary calendar utilities
require_once dirname( SIMPLE_CALENDAR_FULLCALENDAR_FILE ) . '/util/calendar-util.php';

// add calendar to a post
function add_simple_calendar($content) {
    // if a single post is displayed
    if (is_single()) {
       // call draw_calendar function with current month and year
       $month = get_current_month();
       $year = get_current_year(); 
       $content .= draw_calendar($month, $year); 
    }
    return $content;
}

// Hook the function to WordPress the_content filter
add_filter('the_content', 'add_simple_calendar');

?>
